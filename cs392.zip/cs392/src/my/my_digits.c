#include "my.h"

void my_digits(){
	int i = 0;
	while(i < 10){
		my_int(i);
		i++; 
	}
}