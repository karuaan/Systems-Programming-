#include "my.h"

void my_alpha(){
	int i = 17; 
	while(i < 43){
		my_char('0' + i);
		i++;
	}
}