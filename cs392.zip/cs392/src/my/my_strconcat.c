#include "my.h"


char *my_strconcat(char *a, char *b){

	if(a == NULL && b == NULL){
		return NULL;
	}

	if(a == NULL){
		int y = my_strlen(b) + 1; 
		char *test = (char*) malloc(y * sizeof(char));
		return my_strcpy(test,b); 
	}

	if(b == NULL){
		int z = my_strlen(b) + 1; 
		char *test2 = (char*) malloc(z * sizeof(char));
		return my_strcpy(test2,a); 
	}

	int x = my_strlen(a) + my_strlen(b) + 1;


	char *dst = (char*) malloc(x * sizeof(char));

	dst = my_strcat(dst,a);
	dst = my_strcat(dst,b);


	return dst;




}