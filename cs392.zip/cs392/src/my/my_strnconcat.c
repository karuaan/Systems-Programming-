#include "my.h"

char *my_strnconcat(char *a, char *b, int n){

	// char* str = my_strconcat(a,b);
	// int x = my_strlen(a) + n + 1; 
	// char* str2 = (char*) malloc((x + 1) * sizeof(char)); 

	// return my_strncpy(str2,str,n + my_strlen(a));



	// char* str = (char*) malloc((n + 1) * sizeof(char)); 
	// str = my_strncpy(str,b,n);

	// if(a == NULL && b == NULL){
	// 	my_char('a');
	// 	return NULL; 
	// }

	// if(b == NULL){
	// 	my_char('b');
	// 	return a; 
	// }

	// my_char('c');

	// return my_strconcat(a,str);

	// int x;
	// int count = 0;

	// if(n > my_strlen(b)){
	// 	x += my_strlen(b);
	// } 

	// else {
	// 	x += n;
	// }

	// if(a == NULL && b == NULL){
	// 	return NULL; 
	// }



	// char *str = (char*) malloc(x * sizeof(char)); 
	// while(count < n){
	// 	str[count] = b[count];
	// 	count++;
	// }

	// str[count] = "\0"; 

	// return my_strconcat(a,str);




	int count = 0;
	char *str = (char*) malloc(x * sizeof(char));

	if(a == NULL && b == NULL){
		return NULL;
	}

	if(a == NULL){
		while(count < n){
			str[count] = b[count];
			count++;
		}

		return str; 

	}

	if(b == NULL){
		return a;
	}


	count = 0;

	int checker = 0; 
	

	while(count < my_strlen(a)){
		str[count] = a[count];
		count++; 
	}

	while(checker < n){
		str[count] = b[checker];
		count ++;
		checker++;
	}



	return str;


}