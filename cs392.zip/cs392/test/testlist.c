#include "mylist.h"

int main(int argc, char** argv)
{
	char* data = "HelloWorld!";
	struct s_node* list = NULL;

	for (char* c = data; *c != '\0'; c++) {
		append(new_node(c, NULL, NULL), &list);
	}
	my_int(count_s_nodes(list));
	my_str(": ");
	traverse_char(list);
	my_char('\n');

	for (int i = -1; i <= count_s_nodes(list); i++) {
		print_char(node_at(list, i));
		my_str(", ");
	}
	my_char('\n');

	for (int i = -1; i <= count_s_nodes(list); i++) {
		my_char(*(((char*)(elem_at(list, i)))));
		my_str(", ");
	}
	my_char('\n');

	/*
	empty_list(&list);
	my_int(count_s_nodes(list));
	my_str(": ");
	traverse_char(list);
	my_char('\n');
	*/

	while (list != NULL) {
		remove_node_at(&list, 1);
		my_int(count_s_nodes(list));
		my_str(": ");
		traverse_char(list);
		my_char('\n');
	}

	return 0;
}
